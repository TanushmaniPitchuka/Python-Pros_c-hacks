DROPPLY — COMPLETE ASSET COLLECTION

assets/: all project artwork, sprite animation frames, reusable tiles, props, enemies, sound effects, boss music, and included source/reference art and generation records. Original folder names are preserved.

maps/: editable tile maps, atlas descriptions, campaign layouts and chapter roadmap.

procedural-effects/controller.js: source for visuals and animations drawn at runtime, including water trails, dash, Nova, poison lightning, interface meters and the final lake cinematic. These effects do not exist as individual PNG or video files.

resource-index.json: resources registered in the native GDevelop project.
file-manifest.json: every collected file, size and SHA-256 hash.

This is an asset/source collection, not the playable game. Source references and prompt records are retained where present. User-supplied music and third-party art keep their original ownership and licensing.
